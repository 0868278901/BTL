
class User {
    constructor(uid, email) {
        this.uid = uid;
        this.email = email;
    }
}

module.exports = User;
