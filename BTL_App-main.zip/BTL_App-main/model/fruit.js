class Fruit{
    constructor(baoquan, discription,id, kcal, name, 
        organic, price, start, imgurl){
        this.baoquan = baoquan;
        this.discription = discription;
        this.id = id;
        this.kcal = kcal;
        this.name = name;
        this.price = price;
        this.organic = organic;
        this.start = start;
        this.imgurl = imgurl;
    }
}


module.exports = Fruit;
